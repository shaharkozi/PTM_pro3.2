package test;


public class TimeSeries {
	
	
	public TimeSeries(String csvFileName) {
	}
	
}
